from bs4 import BeautifulSoup
from enums.DetectionMethod import DetectionMethod
from MLService import MLService

import math


class OpenScenarioDetector:

    def __init__(self, detection_method):
        file = './scenario_defs/overtake_test.xosc' if detection_method != DetectionMethod.HYBRID else './scenario_defs/overtake_hybrid_test.xosc'
        self.ml_service = None
        with open(file, 'r') as f:
            data = f.read()

        self.overtake_data = BeautifulSoup(data, "xml")
        self.openscenario_registered_dict = {}
        self.openscenario_tracking_dict = {}

    def verify_condition_groups(self, condition_groups, vehicle):
        for condition_group in range(len(condition_groups)):
            condition_met = self.verify_conditions(condition_groups[condition_group].find_all('Condition'), vehicle)
            if condition_met:
                return True
        return False

    def verify_conditions(self, conditions, vehicle):
        condition_met = True
        for c in range(len(conditions)):
            condition = conditions[c]

            if len(condition.find_all('RelativeDistanceCondition')) > 0:
                relative_distance_conditions = condition.find_all('RelativeDistanceCondition')
                for rdc in range(len(relative_distance_conditions)):
                    if not verify_relative_distance_condition(relative_distance_conditions[rdc], vehicle):
                        condition_met = False
                if condition_met:
                    return True

                return False

            elif len(condition.find_all('CustomCondition')) > 0:
                custom_conditions = condition.find_all('CustomCondition')
                for custom_condition in range(len(custom_conditions)):
                    children = custom_conditions[custom_condition].findChildren()
                    for child in children:
                        if child.name == 'MachineLearningPredict':
                            if not self.ml_service:
                                print("instantiating ML model")
                                self.ml_service = MLService(child["model"])
                            if child["rule"] == "equalTo":
                                if self.ml_service.detect_overtake_ml(vehicle) == int(child["value"]):
                                    return True

                return False

    def remove_from_openscenario_dict(self, veh_id):
        try:
            self.openscenario_tracking_dict.pop(veh_id)
        except KeyError:
            pass

    def get_start_time(self, veh_id):
        start_time = self.openscenario_registered_dict.get(veh_id)
        self.openscenario_registered_dict.pop(veh_id)
        return start_time

    def verify_overtake_hybrid(self, veh_id, epoch_time, vehicle):
        latitude, longitude = point_pos(vehicle["distance"][-1], vehicle["angle_from_center"][-1])

        story = self.overtake_data.find_all('Story')
        acts = story[0].find_all('Act')
        events = acts[0].find_all('Event')

        if veh_id not in self.openscenario_tracking_dict:
            if self.verify_condition_groups(events[0].find_all('ConditionGroup'), vehicle):
                # print("Adding", vehicle["vehicle_type"], "to tracking list...")
                self.openscenario_tracking_dict[veh_id] = epoch_time
        else:
            if len(events[1].find_all('ConditionGroup')) > 0:
                if self.verify_condition_groups(events[1].find_all('ConditionGroup'), vehicle):
                    self.openscenario_registered_dict[veh_id] = self.openscenario_tracking_dict.get(veh_id)
                    self.remove_from_openscenario_dict(veh_id)
                    return True
            else:
                if self.verify_conditions(events[1].find_all('Condition'), vehicle):
                    self.openscenario_registered_dict[veh_id] = self.openscenario_tracking_dict.get(veh_id)
                    self.remove_from_openscenario_dict(veh_id)
                    return True

        return False


def point_pos(d, theta):
    theta_rad = math.pi / 2 - math.radians(theta)
    return d * math.cos(theta_rad), d * math.sin(theta_rad)


def verify_relative_distance_condition(relative_distance_conditions, vehicle):
    lateral, longitudinal = point_pos(vehicle["distance"][-1], vehicle["angle_from_center"][-1])

    dist = lateral if relative_distance_conditions["relativeDistanceType"] == "lateral" else longitudinal
    val = float(relative_distance_conditions["value"])

    if relative_distance_conditions["rule"] == "greaterThan":
        if dist > val:
            return True
    elif relative_distance_conditions["rule"] == "lessThan":
        if dist < val:
            return True
    else:
        if dist == val:
            return True

    return False
