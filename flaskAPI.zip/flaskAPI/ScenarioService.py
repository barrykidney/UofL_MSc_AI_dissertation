from OpenScenarioDetector import OpenScenarioDetector
from MLService import MLService


class ScenarioService:

    def __init__(self, app, detection_method):
        self.app = app
        self.scenario_list = {}
        self.open_scenario_detector = OpenScenarioDetector(detection_method)
        self.ml_service = MLService("overtakes_xgb_acc100.pickle")

    def add_scenario_by_vin(self, vin, scenario):
        if vin in self.scenario_list:
            self.scenario_list[vin].append(scenario)
        else:
            self.scenario_list = {vin: [scenario]}

    def get_all_vins(self):
        return list(self.scenario_list.keys())

    def get_number_of_scenarios_by_vin(self, vin):
        if vin in self.scenario_list:
            return len(self.scenario_list[vin])
        else:
            print("vin not found")

    def get_all_scenarios_by_vin(self, vin):
        if vin in self.scenario_list:
            return self.scenario_list[vin]
        else:
            print("vin not found")

    def remove_from_openscenario_list(self, veh_id):
        self.open_scenario_detector.remove_from_openscenario_dict(veh_id)

    def detect_overtake_openscenario(self, vin, veh_id, epoch_time, vehicle):
        if self.open_scenario_detector.verify_overtake_hybrid(veh_id, epoch_time, vehicle):
            self.add_scenario_by_vin(vin, create_scenario_object(vin, self.open_scenario_detector.get_start_time(veh_id), vehicle["epoch_time"][-1], [vehicle["vehicle_type"]]))
            return True

        return False

    def detect_overtake_deterministic(self, vin, vehicle):
        if abs(vehicle["angle_from_center"][-1]) > 105 and vehicle["distance"][-1] > (abs(vehicle["angle_from_center"][-1]) * -0.2) + 41:
            for i in range(-2, -len(vehicle["angle_from_center"]) - 1, -1):
                if abs(vehicle["angle_from_center"][i]) < 75.0 and vehicle["distance"][i] > (abs(vehicle["angle_from_center"][i]) * 0.2) + 5:
                    self.add_scenario_by_vin(vin, create_scenario_object(vin, vehicle["epoch_time"][i], vehicle["epoch_time"][-1], [vehicle["vehicle_type"]]))
                    return True
        return False

    def detect_overtaken_deterministic(self, vin, vehicle):
        if abs(vehicle["angle_from_center"][-1]) < 75.0 and vehicle["distance"][-1] > (abs(vehicle["angle_from_center"][-1]) * 0.2) + 5:
            for i in range(-2, -len(vehicle["angle_from_center"])-1, -1):
                if abs(vehicle["angle_from_center"][i]) > 105 and vehicle["distance"][i] > (abs(vehicle["angle_from_center"][i]) * -0.2) + 41:
                    self.add_scenario_by_vin(vin, create_scenario_object(vin, vehicle["epoch_time"][i], vehicle["epoch_time"][-1], [vehicle["vehicle_type"]]))
                    return True
        return False

    def detect_overtake_ml(self, vin, vehicle):
        if self.ml_service.detect_overtake_ml(vehicle):
            self.add_scenario_by_vin(vin, create_scenario_object(vin, vehicle["epoch_time"][0], vehicle["epoch_time"][-1], [vehicle["vehicle_type"]]))
            return True
        return False


def create_scenario_object(vin, start_time, end_time, vehicle_type, type="ego_veh_overtakes_other"):
    return {
        "vin": vin,
        "type": type,
        "start_time": start_time,
        "end_time": end_time,
        "actors": vehicle_type
    }
