from enum import Enum, auto


class OpenScenarioRules(Enum):
    lessThan = auto()
    greaterThan = auto()
    equalTo = auto()
