from enum import Enum, auto


class DetectionMethod(Enum):
    DETERMINISTIC = auto()
    OPENSCENARIO = auto()
    MACHINELEARNING = auto()
    HYBRID = auto()
