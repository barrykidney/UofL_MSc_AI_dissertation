import numpy as np
import pandas as pd
import pickle
from scipy.interpolate import interp1d


class MLService:

    def __init__(self, model_file):
        self.classifier = pickle.load(open(model_file, "rb"))
        self.df = create_empty_dataframe(100)
        self.minmax = [[1.301978720789499994e-03, 1.799998235718559840e+02],
                       [1.278883480445852427e+00, 1.997575673610176139e+01],
                       [-1.064928908997496215e+01, 6.747276632907928118e+00]]

    def detect_overtake_ml(self, vehicle):
        arr = regularize_feature_timesteps([vehicle["angle_from_center"], vehicle["distance"], vehicle["velocity_delta"]], 100)
        arr = self.normalize_row(arr)
        self.populate_df(arr)
        y_pred = self.classifier.predict(self.df)
        if y_pred[0] == 1:
            return True

        return False

    def normalize_row(self, arr):
        norm_row = []
        for p in range(3):
            norm_feat = []
            diff = 1 - 0
            diff_arr = self.minmax[p][1] - self.minmax[p][0]
            feat_cols = arr[p * 100: p * 100 + 100]

            for i in feat_cols:
                temp = (((i - self.minmax[p][0]) * diff) / diff_arr) + 0
                norm_feat.append(temp)
            norm_row = norm_row + norm_feat

        return norm_row

    def populate_df(self, arr):
        self.df.drop(self.df.index, inplace=True)
        self.df.loc[len(self.df.index)] = arr


def create_empty_dataframe(df_size):
    columns = []
    for feature in ["a", "d", "v"]:
        for i in range(1, df_size + 1):
            columns.append(feature + str(i))
    temp_df = pd.DataFrame(columns=columns)

    for feature in ["a", "d", "v"]:
        for i in range(1, df_size + 1):
            temp_df[feature + str(i)] = temp_df[feature + str(i)].astype(float)

    return temp_df


def regularize_feature_timesteps(feature_list, no_of_timesteps):
    new_array = []
    x = np.arange(len(feature_list[0]))
    increment = len(x) / (no_of_timesteps -1)

    for y in feature_list:
        interp_func = interp1d(x, y, axis=0, fill_value="extrapolate")
        new_array = np.concatenate([new_array, interp_func(np.arange(0, increment * 100, increment))])

    return new_array
