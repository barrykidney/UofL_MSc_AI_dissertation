import pandas as pd
import time
from scipy.interpolate import interp1d
import numpy as np
import datetime
import math

# df = pd.read_csv('output_file.csv')
#
#
# def regularize_feature_timesteps(self, feature_list, no_of_timesteps):
#     temp_df = self.create_empty_dataframe(100)
#     x = [*range(1, len(feature_list[0]) + 1)]
#     new_array = []
#
#     for feat_idx, feature in enumerate(feature_list):
#         y = np.array(feature)
#         intercept_increment = len(feature) / (no_of_timesteps - 1)
#
#         for i in range(no_of_timesteps):
#             new_array.append(np.interp(intercept_increment * i, x, y))
#
#     return new_array
#
#
#


# print(lll)
# lll.sort()
# print(lll)
#
# for i in lll[1:]:
#     print(i)
# for l in lll:
#     print(l[1] - l[0])

# delta = 1689530071.154703 - 1689529945.429663
# print(delta)
#
# print(str(datetime.timedelta(seconds = delta)))


d = 953023071.154703154703

print("Total amount of data gathered {:,} MegaBytes".format(round(d, 2)))


