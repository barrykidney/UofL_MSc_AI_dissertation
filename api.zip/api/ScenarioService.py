import time
import pandas as pd
import pickle
import xgboost as xgb
import math
import numpy as np
import datetime
from scipy.interpolate import interp1d

class ScenarioService:

    def __init__(self, app):
        self.app = app
        self.scenario_list = {}
        self.classifier = pickle.load(open("overtakes_xgb_acc100.pickle", "rb"))
        self.minmax = [[1.301978720789499994e-03, 1.799998235718559840e+02],
                       [1.278883480445852427e+00, 1.997575673610176139e+01],
                       [-1.064928908997496215e+01, 6.747276632907928118e+00]]
        self.df = self.create_empty_dataframe(100)
        self.feature_indicators = ["a", "d", "v"]

    def create_empty_dataframe(self, df_size):
        columns = []
        for feature in ["a", "d", "v"]:
            for i in range(1, df_size +1):
                columns.append(feature + str(i))
        temp_df = pd.DataFrame(columns=columns)

        for feature in ["a", "d", "v"]:
            for i in range(1, df_size +1):
                temp_df[feature + str(i)] = temp_df[feature + str(i)].astype(float)

        return temp_df

    def add_scenario_by_vin(self, vin, scenario):
        if vin in self.scenario_list:
            self.scenario_list[vin].append(scenario)
        else:
            self.scenario_list = {vin: [scenario]}

    def get_all_vins(self):
        return list(self.scenario_list.keys())

    def get_number_of_scenarios_by_vin(self, vin):
        if vin in self.scenario_list:
            return len(self.scenario_list[vin])
        else:
            print("vin not found")

    def get_all_scenarios_by_vin(self, vin):
        if vin in self.scenario_list:
            return self.scenario_list[vin]
        else:
            print("vin not found")

    def detect_overtake_deterministic(self, vin, vehicle):
        if abs(vehicle["angle_from_center"][-1]) > 105 and vehicle["distance"][-1] > (abs(vehicle["angle_from_center"][-1]) * -0.2) + 41:
            for i in range(-2, -len(vehicle["angle_from_center"]) - 1, -1):
                if abs(vehicle["angle_from_center"][i]) < 75.0 and vehicle["distance"][i] > (abs(vehicle["angle_from_center"][i]) * 0.2) + 5:

                    scenario = {
                        "vin": vin,
                        "type": "ego_veh_overtakes_other",
                        "start_time": vehicle["epoch_time"][i],
                        "end_time": vehicle["epoch_time"][-1],
                        "actors": [vehicle["vehicle_type"]]
                    }

                    self.add_scenario_by_vin(vin, scenario)
                    return True
        return False

    def detect_overtaken_deterministic(self, vin, vehicle):
        if abs(vehicle["angle_from_center"][-1]) < 75.0 and vehicle["distance"][-1] > (abs(vehicle["angle_from_center"][-1]) * 0.2) + 5:
            for i in range(-2, -len(vehicle["angle_from_center"])-1, -1):
                if abs(vehicle["angle_from_center"][i]) > 105 and vehicle["distance"][i] > (abs(vehicle["angle_from_center"][i]) * -0.2) + 41:

                    scenario = {
                        "vin": vin,
                        "type": "ego_veh_overtaken_by_other",
                        "start_time": vehicle["epoch_time"][i],
                        "end_time": vehicle["epoch_time"][-1],
                        "actors": [vehicle["vehicle_type"]]
                    }

                    self.add_scenario_by_vin(vin, scenario)
                    return True
        return False

    def populate_df(self, arr):
        self.df.drop(self.df.index, inplace=True)
        self.df.loc[len(self.df.index)] = arr

    def detect_overtake_ml(self, vin, vehicle, ct):
        # print("before pre-prossing", time.time() - ct)
        arr = self.regularize_feature_timesteps([vehicle["angle_from_center"], vehicle["distance"], vehicle["velocity_delta"]], 100)
        # print("after regularize", time.time() - ct)
        arr = self.normalize_row(arr)
        # print("after norm", time.time() - ct)
        self.populate_df(arr)
        # print("after populate_df", time.time() - ct)
        y_pred = self.classifier.predict(self.df)
        # print("After predict", time.time() - ct)
        if y_pred[0] == 1:
            print("OVERTAKE DETECTED -", vehicle["vehicle_type"], " : ", datetime.datetime.fromtimestamp(vehicle["epoch_time"][0]))
            scenario = {
                "vin": vin,
                "type": "ego_veh_overtakes_other",
                "start_time": vehicle["epoch_time"][0],
                "end_time": vehicle["epoch_time"][-1],
                "actors": [vehicle["vehicle_type"]]
            }

            self.add_scenario_by_vin(vin, scenario)
            return True

        return False


    def regularize_feature_timesteps(self, feature_list, no_of_timesteps):
        new_array = []
        x = np.arange(len(feature_list[0]))
        increment = len(x) / (no_of_timesteps -1)

        for y in feature_list:
            interp_func = interp1d(x, y, axis=0, fill_value="extrapolate")
            new_array = np.concatenate([new_array, interp_func(np.arange(0, increment * 100, increment))])

        return new_array


    def normalize_row(self, arr):
        norm_row = []
        for p in range(3):
            norm_feat = []
            diff = 1 - 0
            diff_arr = self.minmax[p][1] - self.minmax[p][0]
            feat_cols = arr[p * 100: p * 100 + 100]

            for i in feat_cols:
                temp = (((i - self.minmax[p][0]) * diff) / diff_arr) + 0
                norm_feat.append(temp)
            norm_row = norm_row + norm_feat

        return norm_row
