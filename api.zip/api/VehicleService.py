import time

from ScenarioService import ScenarioService
import csv
import pandas as pd
import datetime
import json

class VehicleService:

    def __init__(self, app):
        self.app = app
        self.scenario_service = ScenarioService(app)
        self.tracking_list = {}
        self.ego_vehicle =  {"vin": "1234"}
        self.df = pd.read_csv('output_file.csv')
        self.app.logger.warning("VehicleService init...")
        self.output_file = "output_file.csv"
        self.data_dump_file = "data_dump_file.json"
        self.data_dump_list = []
        self.data_dump = False
        self.dict = {}
        self.dict_idx = 0
        self.record_nonscenario_data = False
        self.use_deterministic_scenario_detection = False
        self.calls = 1
        self.previous_check_time = time.time()
        self.data_colection_start_time = None
        self.data_colection_end_time = None

    def set_ego_vehicle(self, vin):
        self.ego_vehicle = {"vin": vin}
    
    def get_ego_vehicle(self, vin):
        return None if self.ego_vehicle == None else self.ego_vehicle["vin"]

    def set_data_colection_start_time(self, start_time):
        print("Vehicle " + self.ego_vehicle["vin"] + " started gathering data at " + str(datetime.datetime.fromtimestamp(start_time)))
        self.data_colection_start_time = start_time

    def set_data_colection_end_time(self, end_time):
        self.data_colection_end_time = end_time
        total_scenario_time = 0
        scenario_list = self.scenario_service.get_all_scenarios_by_vin(self.ego_vehicle["vin"])
        if scenario_list and len(scenario_list) > 0:
            time_blocks_list = []
            for scenario in scenario_list:
                time_blocks_list.append([scenario["start_time"], scenario["end_time"]])

            merged_time_blocks = self.merge_scenario_time_blocks(time_blocks_list)

            for time_block in merged_time_blocks:
                total_scenario_time += time_block[1] - time_block[0]

        print("")
        print("Vehicle {} finished gathering data at {}".format(self.ego_vehicle["vin"], str(datetime.datetime.fromtimestamp(end_time))))
        print("Data gathering lasted for {}".format(datetime.timedelta(seconds=(self.data_colection_end_time - self.data_colection_start_time))))
        print("Total amount of data gathered {:,} MegaBytes".format(round((self.data_colection_end_time - self.data_colection_start_time) * 868, 2)))
        print("Amount of scenario data {:,} MegaBytes".format(round(total_scenario_time * 868, 2)))
        print("")

    def add_vehicle_to_tracking_list(self, vehicle, epoch_time):
        # print("Adding Vehicle to tracking list. " +  datetime.datetime.now().strftime("%H:%M:%S.%f") + ", ", end='')
        self.tracking_list[str(vehicle["vehicle_id"])] = {
            "vehicle_type": vehicle["vehicle_type"],
            "epoch_time": [epoch_time],
            "angle_from_center": [vehicle["angle_from_center"]],
            "distance": [vehicle["distance"]],
            "velocity_delta": [vehicle["velocity_delta"]]
        }
        # print("updated tracking list: " + str(list(self.tracking_list.keys())))
        return True

    def add_data_to_tracked_vehicle(self, vehicle, epoch_time):
        method_start_time = time.time()
        # if self.data_dump:
        #     self.data_dump_list.append({"time": epoch_time, "vehicle":vehicle})
        ep_tm = epoch_time
        # print(self.calls, ":", datetime.datetime.fromtimestamp(ep_tm))
        self.calls += 1

        if str(vehicle["vehicle_id"]) in self.tracking_list:
            if vehicle["distance"] > 20.0:
                self.delete_tracked_vehicle_by_id(str(vehicle["vehicle_id"]))
            else:
                # print("Adding data to existing tracked vehicle.")
                if len(self.tracking_list[str(vehicle["vehicle_id"])]["epoch_time"]) > 249:
                    self.tracking_list[str(vehicle["vehicle_id"])]["epoch_time"].pop(0)
                    self.tracking_list[str(vehicle["vehicle_id"])]["angle_from_center"].pop(0)
                    self.tracking_list[str(vehicle["vehicle_id"])]["distance"].pop(0)
                    self.tracking_list[str(vehicle["vehicle_id"])]["velocity_delta"].pop(0)

                self.tracking_list[str(vehicle["vehicle_id"])]["epoch_time"].append(epoch_time)
                self.tracking_list[str(vehicle["vehicle_id"])]["angle_from_center"].append(vehicle["angle_from_center"])
                self.tracking_list[str(vehicle["vehicle_id"])]["distance"].append(vehicle["distance"])
                self.tracking_list[str(vehicle["vehicle_id"])]["velocity_delta"].append(vehicle["velocity_delta"])

                current_time = time.time()
                if current_time - self.previous_check_time > .5 and len(self.tracking_list[str(vehicle["vehicle_id"])]["epoch_time"]) > 50:
                    self.previous_check_time = current_time
                    self.dict[self.dict_idx] = self.create_csv_row(vehicle["vehicle_id"], self.tracking_list[str(vehicle["vehicle_id"])], 'N', 'N')
                    self.dict_idx = self.dict_idx + 1
                    # print("NO SCENARIO DETECTED : len(df): " + str(len(self.dict)))

                    # scenario_detected = False

                    # if self.use_deterministic_scenario_detection:
                    #     if self.scenario_service.detect_overtake_deterministic(self.ego_vehicle["vin"], self.tracking_list[str(vehicle["vehicle_id"])]):
                    #         print("EGO VEHICLE HAS OVERTAKEN " + self.tracking_list[str(vehicle["vehicle_id"])]["vehicle_type"] + " AT " + datetime.datetime.now().strftime("%H:%M:%S.%f"))
                    #         new_row = self.create_csv_row(vehicle["vehicle_id"], self.tracking_list[str(vehicle["vehicle_id"])], 'Y', 'N')
                    #         self.df = self.df.append(new_row, ignore_index=True)
                    #         scenario_detected = True
                    #
                    #     if self.scenario_service.detect_overtaken_deterministic(self.ego_vehicle["vin"], self.tracking_list[str(vehicle["vehicle_id"])]):
                    #         print("EGO VEHICLE HAS BEEN OVERTAKEN BY " + self.tracking_list[str(vehicle["vehicle_id"])]["vehicle_type"] + " AT " + datetime.datetime.now().strftime("%H:%M:%S.%f"))
                    #         new_row = self.create_csv_row(vehicle["vehicle_id"], self.tracking_list[str(vehicle["vehicle_id"])], 'N', 'Y')
                    #         self.df = self.df.append(new_row, ignore_index=True)
                    #         scenario_detected = True
                    # else:
                    if self.scenario_service.detect_overtake_ml(self.ego_vehicle["vin"], self.tracking_list[str(vehicle["vehicle_id"])], method_start_time):
                        self.clear_data_from_vehicle_in_tracking_list(str(vehicle["vehicle_id"]))
                    #     scenario_detected = True
                    #
                    # if scenario_detected:
                    #     self.clear_data_from_vehicle_in_tracking_list(str(vehicle["vehicle_id"]))
                    #     scenario_detected = False
                    # elif self.record_nonscenario_data and not scenario_detected:
                    #     self.dict[self.dict_idx] = self.create_csv_row(vehicle["vehicle_id"], self.tracking_list[str(vehicle["vehicle_id"])], 'N', 'N')
                    #     self.dict_idx = self.dict_idx + 1
                    #     # print("NO SCENARIO DETECTED " + str(
                    #     #     len(self.tracking_list[str(vehicle["vehicle_id"])]["epoch_time"])) + ", len(df): " + str(len(self.dict))+ " : " +
                    #     #       self.tracking_list[str(vehicle["vehicle_id"])][
                    #     #           "vehicle_type"] + " AT " + datetime.datetime.now().strftime("%H:%M:%S.%f"))

            return True
        else:
            if vehicle["distance"] <= 20.0:
                # print("Vehicle (" + str(vehicle["vehicle_id"]) + ") not found in tracking list (" + str(list(self.tracking_list.keys())) + ") ", end='')
                self.add_vehicle_to_tracking_list(vehicle, epoch_time)
                return True

    def get_tracked_vehicle_by_id(self, vehicle_id):
        try:
            return self.tracking_list[vehicle_id]
        except KeyError:
            return False

    def clear_data_from_vehicle_in_tracking_list(self, vehicle_id):
        self.tracking_list[vehicle_id]["epoch_time"] = []
        self.tracking_list[vehicle_id]["angle_from_center"] = []
        self.tracking_list[vehicle_id]["distance"] = []
        self.tracking_list[vehicle_id]["velocity_delta"] = []

    def get_all_tracked_vehicle_ids(self):
        return list(self.tracking_list.keys())

    def delete_tracked_vehicle_by_id(self, vehicle_id):
        tracked_vehicle = self.get_tracked_vehicle_by_id(vehicle_id)
        del self.tracking_list[vehicle_id]
        return tracked_vehicle

    def delete_all_tracked_vehicles(self):
        tracked_vehicle_ids = self.get_all_tracked_vehicle_ids()
        self.tracking_list.clear()
        return tracked_vehicle_ids
    
    def get_all_vins(self):
        return self.scenario_service.get_all_vins()

    def create_csv_row(self, id, vehicle, overtakes, overtaken):
        new_row = {}

        new_row['vehicle_id'] = id
        new_row['ego_veh_overtakes_other'] = overtakes
        new_row['ego_veh_overtaken_by_other'] = overtaken
        new_row['vehicle_type'] = vehicle['vehicle_type']

        col_idx = 250
        for i in range(-1, -len(vehicle['epoch_time']) -1, -1):
            new_row["t" + str(col_idx)] = vehicle['epoch_time'][i]
            new_row["a" + str(col_idx)] = vehicle['angle_from_center'][i]
            new_row["d" + str(col_idx)] = vehicle['distance'][i]
            new_row["v" + str(col_idx)] = vehicle['velocity_delta'][i]

            col_idx -=1
        return new_row

    def get_all_scenarios_by_vin(self, vin):
        return self.scenario_service.get_all_scenarios_by_vin(vin)
    
    def get_number_of_scenarios_by_vin(self, vin):
        return self.scenario_service.get_number_of_scenarios_by_vin(vin)
        
    def save_db_to_csv(self):
        temp_df = pd.DataFrame.from_dict(self.dict, "index")
        temp_df.to_csv("output_file_2.csv", index=False)
        # print("saving " + str(len(self.df.index)) + " rows to file, " + self.output_file)
        # self.df.to_csv(self.output_file, index=False)

    def save_data_dump_to_file(self):
        with open(self.data_dump_file, 'w') as fout:
            json.dump(self.data_dump_list, fout)

    def merge_scenario_time_blocks(self, time_blocks):
        time_blocks.sort()
        stack = []
        stack.append(time_blocks[0])
        for i in time_blocks[1:]:
            if stack[-1][0] <= i[0] <= stack[-1][-1]:
                stack[-1][-1] = max(stack[-1][-1], i[-1])
            else:
                stack.append(i)

        return stack
